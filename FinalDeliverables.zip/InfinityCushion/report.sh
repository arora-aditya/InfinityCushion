#!/bin/sh

oled-exp -c
oled-exp draw report.lcd
sleep 1
./aggregateTime.o